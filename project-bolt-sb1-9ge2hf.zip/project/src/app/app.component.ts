import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { EmployeeFormComponent } from './components/employee-form/employee-form.component';
import { EmployeeListComponent } from './components/employee-list/employee-list.component';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, EmployeeFormComponent, EmployeeListComponent],
  template: `
    <div class="min-h-screen bg-gray-100">
      <header class="bg-white shadow">
        <div class="max-w-7xl mx-auto py-6 px-4">
          <h1 class="text-3xl font-bold text-gray-900">Employee Management System</h1>
        </div>
      </header>
      <main class="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
        <app-employee-form />
        <app-employee-list />
      </main>
    </div>
  `
})
export class AppComponent {
  title = 'Employee Management System';
}